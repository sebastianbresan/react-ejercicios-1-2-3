import React from 'react';
import Contacto from './Contacto.jsx';

const Funcionescontacto = () => {  

    return (
        <div>   
            <h1> BIENVENIDO </h1>
           <Contacto name= "Juan" lastName = "Ferpuncio" email = "juanfer@fer.com"></Contacto>
        </div>
    );
};




export default Funcionescontacto;

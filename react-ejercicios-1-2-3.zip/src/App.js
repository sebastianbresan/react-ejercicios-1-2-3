import './App.css';
import Funcionescontacto from './components/FuncionesContacto';

function App() {
  return (
    <div className="App">
      <header className="App-header">
       <Funcionescontacto></Funcionescontacto>
      </header>
    </div>
  );
}

export default App;
